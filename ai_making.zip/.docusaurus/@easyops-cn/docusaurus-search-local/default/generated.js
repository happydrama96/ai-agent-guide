export const removeDefaultStemmer = true;
export { default as Mark } from "C:\\leejh\\00.dev\\Source\\TEST\\ai_making\\node_modules\\mark.js\\dist\\mark.js"
export const searchResultContextMaxLength = 60;
export const explicitSearchResultPath = true;
export const searchBarShortcut = true;
export const searchBarShortcutHint = true;
export const searchBarShortcutKeymap = "mod+k";
export const searchBarPosition = "right";
export const docsPluginIdForPreferredVersion = undefined;
export const indexDocs = true;
export const searchContextByPaths = null;
export const hideSearchBarWithNoSearchContext = false;
export const useAllContextsWithNoSearchContext = false;
export const askAi = null;