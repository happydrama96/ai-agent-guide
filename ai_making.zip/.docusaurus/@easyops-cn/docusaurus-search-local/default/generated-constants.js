import lunr from "C:\\leejh\\00.dev\\Source\\TEST\\ai_making\\node_modules\\lunr\\lunr.js";
export const removeDefaultStopWordFilter = ["en"];
export const language = ["en"];
export const searchIndexUrl = "search-index{dir}.json?_=03a395cf";
export const searchResultLimits = 8;
export const fuzzyMatchingDistance = 1;