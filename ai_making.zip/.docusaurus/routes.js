import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/__docusaurus/debug',
    component: ComponentCreator('/__docusaurus/debug', '5ff'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/config',
    component: ComponentCreator('/__docusaurus/debug/config', '5ba'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/content',
    component: ComponentCreator('/__docusaurus/debug/content', 'a2b'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/globalData',
    component: ComponentCreator('/__docusaurus/debug/globalData', 'c3c'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/metadata',
    component: ComponentCreator('/__docusaurus/debug/metadata', '156'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/registry',
    component: ComponentCreator('/__docusaurus/debug/registry', '88c'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/routes',
    component: ComponentCreator('/__docusaurus/debug/routes', '000'),
    exact: true
  },
  {
    path: '/',
    component: ComponentCreator('/', '63c'),
    routes: [
      {
        path: '/',
        component: ComponentCreator('/', '0e9'),
        routes: [
          {
            path: '/',
            component: ComponentCreator('/', '3b4'),
            routes: [
              {
                path: '/about/content-guide',
                component: ComponentCreator('/about/content-guide', '110'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/about/site-policy',
                component: ComponentCreator('/about/site-policy', '698'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/getting-started/comparison',
                component: ComponentCreator('/getting-started/comparison', '2e9'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/getting-started/first-run',
                component: ComponentCreator('/getting-started/first-run', 'f15'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/integrations/internal-docs',
                component: ComponentCreator('/integrations/internal-docs', 'ffa'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/integrations/mcp',
                component: ComponentCreator('/integrations/mcp', '5fd'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/integrations/troubleshooting',
                component: ComponentCreator('/integrations/troubleshooting', 'aa8'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/patterns/by-role',
                component: ComponentCreator('/patterns/by-role', 'f98'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/reference/chatgpt',
                component: ComponentCreator('/reference/chatgpt', 'fe8'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/reference/claude-code',
                component: ComponentCreator('/reference/claude-code', 'f96'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/reference/copilot',
                component: ComponentCreator('/reference/copilot', 'bf0'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/reference/cursor',
                component: ComponentCreator('/reference/cursor', '291'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/setup/chatgpt',
                component: ComponentCreator('/setup/chatgpt', '78d'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/setup/claude-code',
                component: ComponentCreator('/setup/claude-code', 'cdb'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/setup/copilot',
                component: ComponentCreator('/setup/copilot', '8ff'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/setup/cursor',
                component: ComponentCreator('/setup/cursor', '4d0'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/updates/latest',
                component: ComponentCreator('/updates/latest', '6a2'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/',
                component: ComponentCreator('/', '18d'),
                exact: true,
                sidebar: "guideSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
