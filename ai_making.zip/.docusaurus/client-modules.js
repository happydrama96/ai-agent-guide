export default [
  require("C:\\leejh\\00.dev\\Source\\TEST\\ai_making\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\leejh\\00.dev\\Source\\TEST\\ai_making\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\leejh\\00.dev\\Source\\TEST\\ai_making\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\leejh\\00.dev\\Source\\TEST\\ai_making\\src\\css\\custom.css"),
];
